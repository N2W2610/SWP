/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import model.Room;
import java.sql.*;
import java.util.*;
import db.DBContext;
/**
 *
 * @author Dung Thuy
 */
public class RoomDAO {
    public List<Room> searchRooms(String keyword, String area, String priceRange, String sort) throws Exception {
        List<Room> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT * FROM Rooms WHERE 1=1");

        if (keyword != null && !keyword.isEmpty()) {
            sql.append(" AND (title LIKE ? OR address LIKE ?)");
        }
        if (area != null && !area.isEmpty()) {
            sql.append(" AND address LIKE ?");
        }
        if (priceRange != null && !priceRange.isEmpty()) {
            switch (priceRange) {
                case "1": sql.append(" AND price < 1000000"); break;
                case "2": sql.append(" AND price BETWEEN 1000000 AND 2000000"); break;
                case "3": sql.append(" AND price BETWEEN 2000000 AND 3000000"); break;
                case "4": sql.append(" AND price > 3000000"); break;
            }
        }
        if (sort != null) {
            switch (sort) {
                case "new": sql.append(" ORDER BY created_at DESC"); break;
                case "priceAsc": sql.append(" ORDER BY price ASC"); break;
                case "priceDesc": sql.append(" ORDER BY price DESC"); break;
            }
        } else {
            sql.append(" ORDER BY created_at DESC");
        }

        try (Connection conn = new DBContext().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {

            int index = 1;
            if (keyword != null && !keyword.isEmpty()) {
                ps.setString(index++, "%" + keyword + "%");
                ps.setString(index++, "%" + keyword + "%");
            }
            if (area != null && !area.isEmpty()) {
                ps.setString(index++, "%" + area + "%");
            }

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Room r = new Room();
                r.setId(rs.getInt("id"));
                r.setTitle(rs.getString("title"));
                r.setImage(rs.getString("image"));
                r.setAddress(rs.getString("address"));
                r.setPrice(rs.getDouble("price"));
                list.add(r);
            }
        }
        return list;
    }
}
