/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import model.User;

/**
 *
 * @author Dung Thuy
 */
public interface UserDAO {
    // Đăng nhập bằng email + password
    User login(String email, String password) throws Exception;

    // Kiểm tra email đã tồn tại trong hệ thống
    boolean checkEmailExists(String email) throws Exception;

    // Đăng ký thông thường (Sinh viên mặc định)
    void register(String fullName, String email, String password) throws Exception;

    // Đăng ký người dùng đầy đủ (role, sđt, CCCD, OAuth)
    void insertUser(User user) throws Exception;
}
